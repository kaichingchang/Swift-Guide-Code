//
//  檔名： u11.playground
//  專案： u11
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
class Animal {
    let age: Int
    let weight: Int
    
    init(a: Int, w: Int) {
        age = a
        weight = w
    }
    
    func speak() {
        print("我已經" + String(age) + "歲")
        print("體重" + String(weight) + "公斤")
    }
}

class Elephant: Animal {
    let name: String
    
    init(_ ea: Int, _ ew: Int, _ n: String) {
        name = n
        super.init(a: ea, w: ew)
    }
    
    override func speak() {
        print("大家好，我叫" + String(name))
        super.speak()
    }
}

let a = Elephant(3, 350, "大象")
a.speak()

print()

print("第二個例子")

// 第二個例子
protocol Shape {
    var pi: Double {get}
    func area() -> Double
    func perimeter() -> Double
}

class Circle: Shape {
    var pi: Double = 3.14
    var radius: Double
    
    init(_ r: Double) {
        radius = r
    }
    
    func perimeter() -> Double {
        return 2 * pi * radius
    }

    func area() -> Double {
        return pi * radius * radius
    }
}

class Rectangle: Shape {
    var pi: Double = 3.14
    var length: Double
    var width: Double
    
    init(_ l: Double, _ w: Double) {
        length = l
        width = w
    }
    
    func perimeter() -> Double {
        return 2 * (length + width)
    }
    
    func area() -> Double {
        return length * width
    }
}

let b = Circle(20)
print(b.area())
print(b.perimeter())

let c = Rectangle(30, 40)
print(c.area())
print(c.perimeter())

