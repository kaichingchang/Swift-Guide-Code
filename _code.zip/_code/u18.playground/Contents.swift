//
//  檔名： u18.playground
//  專案： u18
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

import Foundation

class Encrypt {
    //MARK: 屬性
    
    // 英文小寫字母表
    let alphabet = "abcdefghijklmnopqrstwuvxyz"
    // 密碼表
    var code = Array(arrayLiteral: 26)
    
    //MARK: 建構子
    
    init() {
        setCode()
    }
    
    //MARK: 方法
    
    // 設定密碼表
    func setCode() {
        var a = 0
        var b = 0
        
        // a 必須是奇數
        while a % 2 == 0 {
            a = Int(arc4random() % 10)
            b = Int(arc4random() % 10)
        }
        
        var c = 97
        var i, x, y, m: Int
        // 設置密碼表中每一個元素的迴圈
        i = 0
        while i < 26 {
            x = c
            y = x * a + b
            m = y % 26
            code.append(m)
            c += 1
            i += 1
        }
        
        // 移除密碼表中的第一個元素
        code.remove(at: 0)
    }
    
    
    // 尋找字元在字母表中的索引值
    func findAlphabetIndex(_ chr: Character) -> Int {
        var i = 0
        for c in alphabet.characters {
            if chr == c {
                return i
            }
            
            i += 1
        }
        
        return 0
    }
    
    // 尋找字元在密碼表中的索引值
    // func findCodeIndex(chr: Character) -> Int {}
    
    // 判斷字元是否是英文小寫字母
    func isLowercase(_ chr: Character) -> Bool {
        for i in alphabet.characters {
            if (chr == i) {
                return true
            }
        }
        
        return false
    }
    
    // 用索引值取得密碼表中的字元
    func findCode(_ number: Int) -> Character {
        let index = code[number]
        var i = 0
        for s in alphabet.characters {
            if i == index {
                return s
            }
            
            i += 1
        }
        
        return Character("")
    }
    
    // 用索引值取得字母表中的字元
    // func findLetter(index: Int) -> Character {}
    
    // 編碼的方法
    func toEncode(_ str: String) -> String {
        var newStr = ""
        for chr in str.characters {
            if isLowercase(chr) {
                newStr.append(findCode(findAlphabetIndex(chr)))
            }
            else {
                newStr.append(chr)
            }
        }
        return newStr
    }
    
    // 解碼的方法
    // func toDecode(str: String) -> String {}
}

//Mark: 測試程式碼
let str = "There is no spoon."
let demo = Encrypt()
let str2 = demo.toEncode(str)
print(str2)
