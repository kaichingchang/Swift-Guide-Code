//
//  檔名： u20.playground
//  專案： u20
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

// 引入必要的框架
import Foundation
import GameplayKit

// 預防參數字串無值的列舉
enum ClearError: Error {
    case NoCodeString
}

// 加密、解密的類別
class Encrypt {
    //MARK: 屬性
    
    // 英文小寫字母表
    let alphabet = Array("abcdefghijklmnopqrstwuvxyz".characters)
    // 密碼表陣列
    var code = [[]]
    // 密碼表字串
    var codeStr = ""
    
    //MARK: 建構子
    
    // 預設建構子，產生隨機密碼表
    init() {
        
        // 取得英文小寫字母隨機排列的陣列
        let temp = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: alphabet)
        code.remove(at: 0)
        
        // 將隨機排列的英文小寫字母放入密碼表陣列
        var i = 0
        while i < 26 {
            code.append([alphabet[i], temp[i]])
            i += 1
        }
        
        // 將密碼表陣列編成密碼表字串
        for item in code {
            let c = item[1] as! Character
            codeStr += String(describing: c)
        }
    }
    
    // 從密碼表字串建立密碼表陣列
    init(_ str: String?) throws {
        // 如果參數無值，丟出錯誤
        if str == nil {
            throw ClearError.NoCodeString
        }
        
        // 建立密碼表陣列
        let temp = Array(str!.characters)
        code.remove(at: 0)
        
        var i = 0
        while i < 26 {
            code.append([alphabet[i], temp[i]])
            i += 1
        }
        
        // 建立密碼表字串
        codeStr = str!
    }
    
    //MARK: 方法
    
    // 判斷是否為英文小寫字母的方法
    func isLowercase(_ string: String) -> Bool {
        // 英文小寫字母集合
        let set = CharacterSet.lowercaseLetters
        
        // 判斷參數是否為英文小寫字母
        if let scala = UnicodeScalar(string) {
            return set.contains(scala)
        }
        else {
            return false
        }
    }
    
    // 編碼方法
    func toEncode(_ str: String) -> String {
        // 暫存結果的空字串
        var newStr = ""
        // 編碼的巢狀迴圈
        for chr in str.characters {
            if isLowercase(String(chr)) {
                for item in code {
                    if chr == item[0] as! Character {
                        if let tempChr = item[1] as? Character {
                            newStr += String(tempChr)
                        }
                    }
                }
            }
            else {
                newStr += String(chr)
            }
        }
        
        return newStr
    }
    
    // 解碼方法
    func toDecode(_ str: String) -> String {
        // 暫存結果的空字串
        var newStr = ""
        // 解碼的巢狀迴圈
        for chr in str.characters {
            if isLowercase(String(chr)) {
                for item in code {
                    if chr == item[1] as! Character {
                        if let tempChr = item[0] as? Character {
                            newStr += String(tempChr)
                        }
                    }
                }
            }
            else {
                newStr += String(chr)
            }
        }
        
        return newStr
    }
}

//Mark: 測試程式碼
let str = "There is no spoon."
let demo = Encrypt()
print(demo.code)
print(demo.codeStr)
let str2 = demo.toEncode(str)
print(str2)
let str3 = demo.toDecode(str2)
print(str3)
