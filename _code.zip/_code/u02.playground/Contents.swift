//
//  檔名： u02.playground
//  專案： u02
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
var a = "Hello"
a = "Hi"
a = "Great"

print()

print("第二個例子")

// 第二個例子
var b = 1, c = 2, d = "中文字串"

print(a)
print(b)
print(c)
print(d)

print()

print("第三個例子")

// 第三個例子
var e: String, f: Int, g: Bool
e = "There is no spoon."
f = 1
g = true

print()


print("第四個例子")

// 第四個例子
let h = 3.14
//h=3.0

print()

print("第五個例子")

// 第五個例子：陣列
var i = [1, 2, 3, 4, 5]
print(i[1])
i[1] = 78
print(i[1])

print()

print("第六個例子")

// 第六個例子：字典
var j = ["1":"a", "2":"yes", "3":"no"]
print(j["3"])
j["3"] = "we"
print(j)
j["3"] = nil
print(j["3"])
j["3"] = "55"
j["4"] = "after"
print(j)

var k = [1:"2", 2:"5", 5:"34"]
print(k[5])

print()

print("第七個例子")

// 第七個例子：選擇型態
var l: Int? = 1
// nil
l = nil

print()

print("第八個例子")

// 第八個例子
l = 5
var m = l!
print(m)

print()

print("第九個例子")

// 第九個例子：序對
var n = (12, "error", 0.314)
print(n.1)
var q = (a:12, b:"error", c:0.314)
print(q.a)

print()

print("第十個例子")

// 第十個例子：
typealias NewInt = UInt16
print(NewInt.max)
