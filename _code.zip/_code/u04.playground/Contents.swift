//
//  檔名： u04.playground
//  專案： u04
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
var a = 5
a
3
print(0)

print()

print("第二個例子")

// 第二個例子
var a1 = -3
var b1 = +a1 // -3
var c1 = -a1 // 3

print()

print("第三個例子")

// 第三個例子
var a2 = true
var b2 = !a2 // false
var c2 = !b2 // true

print()

print("第四個例子")

// 第四個例子
var a3 = 2
var b3 = a3 + 2 // 2
var c3 = b3 - 2 // 4
var d3 = c3 * 2 // 2
var e3 = d3 / 2 // 4
var f3 = e3 % 2 // 0

print()

print("第五個例子")

// 第五個例子
var a4 = 11
var b4 = 22

var c4 = a4 >= b4 // false
var d4 = a4 <= b4 // true
var e4 = c4 == d4 // false
var f4 = a4 != b4 // true

print()

print("第六個例子")

// 第六個例子
var a5 = 2
a5 += 2 // 4
a5 -= 2 // 2
a5 *= 2 // 4
a5 /= 2 // 2
a5 %= 2 // 0

print()

print("第七個例子")

// 第七個例子
f4 = (a4 != b4) // f5 = a4 != b4

print()

print("第八個例子")

// 第八個例子
var a6 = 22; var b6 = 11
