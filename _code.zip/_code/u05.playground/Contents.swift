//
//  檔名： u05.playground
//  專案： u05
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/7/21
//

print("第一個例子")

// 第一個例子
if 3 > 5 {
    print("3大於5發生了")
}

print()

print("第二個例子")

// 第二個例子
if 3 > 5 {
    print("3大於5發生了")
}
else {
    print("還好3沒有大於5")
}

print()

print("第三個例子")

// 第三個例子
if 3 > 5 {
    print("3大於5發生了")
}
else if 4 > 5 {
    print("4大於5發生了")
}
else if 5 > 5 {
    print("5大於5發生了")
}
else if 6 > 5 {
    print("6大於5發生了")
}
else {
    print("以上皆非")
}

print()

print("第四個例子")

// 第四個例子
switch 3+3 {
case 3:
    print("3")

case 4:
    print("4")
    
case 5:
    print("5")
    
case 6:
    print("6.")
    
default:
    print("以上皆非")
}

print()

print("第五個例子")

// 第五個例子
switch "a" {
case "v", "c", "f":
    print("v c f")
    
case "a", "b":
    print("a b")
    
default:
    print("No matches!")
}

print()

print("第六個例子")

// 第六個例子
switch 65 {
case 0...59:
    print("再加油點就及格了喔！")
case 60...69:
    print("好還可以更好！")
case 70...79:
    print("考的不錯！")
case 80...89:
    print("分數很好！")
case 90...99:
    print("成績很棒！")
case 100:
    print("滿分不能再高了！")
default:
    print("無符合分數！")
}
