//
//  檔名： ViewController.swift
//  專案： u25
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/27
//

import Cocoa

class ViewController: NSViewController {
    //MARK: 屬性區
    
    // 使用者輸入欄位
    @IBOutlet weak var inputField: NSTextField!
    // 編碼或解碼輸出欄位
    @IBOutlet weak var outputField: NSTextField!
    // 顯示提示訊息
    @IBOutlet weak var displayLabel: NSTextField!
    
    // 儲存使用者輸入之字串
    var inputString = ""
    // 儲存編碼或解碼結果
    var outputString = ""
    // 編碼屬性
    var e: Encrypt?
    
    // 處理 Core Data 的資料
    let context = (NSApplication.shared().delegate as! AppDelegate).persistentContainer.viewContext
    // 儲存從 Core Data 載入的資料
    var tasks: [Code] = []
    
    //MARK: 方法區
    
    // 新建 Encrypt 屬性
    @IBAction func newMethod(_ sender: NSButton) {
        e = Encrypt()
        displayLabel.stringValue = "密碼表： " + (e?.codeStr)!
    }
    
    // 將密碼表儲存至 Core Data 的資料表
    @IBAction func saveMethod(_ sender: NSButton) {
        // 有建立 Encrypt 屬性後才可儲存
        if e != nil {
            // task 為資料表中 Code 型態物件
            let task = Code(context: context)
            task.codeStr = e?.codeStr
            // 利用 AppDelegate 將 task 儲存至 Core Data
            (NSApplication.shared().delegate as! AppDelegate).saveAction(task)
            displayLabel.stringValue = "密碼表已儲存"
        }
        else {
            displayLabel.stringValue = "無密碼表可儲存"
        }
    }
    
    // 從 Core Data 載入密碼表
    @IBAction func loadMethod(_ sender: NSButton) {
        do {
            // 從 Core Data 的資料表擷取資料
            tasks = try context.fetch(Code.fetchRequest())
            // 用最後一筆資料來設定 Encrypt 屬性
            e = try Encrypt((tasks.last?.codeStr) ?? nil)
            displayLabel.stringValue = "密碼表已載入"
        }
        catch ClearError.NoCodeString {
            // 處理 Core Data 無資料的情況
            displayLabel.stringValue = "無儲存之密碼表"
        }
        catch {
            // 處理任何其他錯誤
            displayLabel.stringValue = "無已儲存密碼表"
        }
    }
    
    // 編碼的方法
    @IBAction func encodeMethod(_ sender: NSButton) {
        // 取得使用者輸入之字串
        inputString = inputField.stringValue
        // 確認使用者有按過「新建」按鈕
        if e != nil {
            // 確認使用者有輸入文字
            if inputString != "" {
                // 編碼轉換
                outputString = (e?.toEncode(inputString))!
                outputField.stringValue = outputString
                displayLabel.stringValue = "編碼結果如上"
            }
            else {
                displayLabel.stringValue = "請輸入欲編碼之英文句子"
            }
        }
        else {
            displayLabel.stringValue = "請先按「新建」按鈕"
        }
    }
    
    // 解碼的方法
    @IBAction func decodeMethod(_ sender: NSButton) {
        // 取得使用者輸入之字串
        inputString = inputField.stringValue
        // 確認使用者有按過「新建」按鈕
        if e != nil {
            // 確認使用者有輸入文字
            if inputString != "" {
                // 解碼轉換
                outputString = (e?.toDecode(inputString))!
                outputField.stringValue = outputString
                displayLabel.stringValue = "解碼結果如上"
            }
            else {
                displayLabel.stringValue = "請輸入欲解碼之英文句子"
            }
        }
        else {
            displayLabel.stringValue = "請先按「新建」按鈕"
        }
    }
    
    @IBAction func clearMethod(_ sender: NSButton) {
        displayLabel.stringValue = "清除"
    }
    
    @IBAction func copyMethod(_ sender: NSButton) {
        displayLabel.stringValue = "拷貝"
    }
    
    // 清除 Core Data 中的所有資料
    func clearDataTable() {
        do {
            tasks = try context.fetch(Code.fetchRequest())
            for item in tasks {
                context.delete(item)
            }
        } catch {
            print("無已儲存密碼表資料")
        }
    }
    
    //MARK: 預設方法
    
    // 視窗載入即執行的方法
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 刪除已儲存的密碼表
        clearDataTable()
    }
    
    // 用來連結至 nib 檔案的實體屬性
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
}

