//
//  檔名： u09.playground
//  專案： u09
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
struct StructDemo {
    // 變數的儲存性屬性
    var a: Int
    // 常數的儲存性屬性
    let b: Int
    
    // 第一個實體方法
    func doSomething() -> Int {
        // 回傳兩個屬性的相加值
        return a + b
    }
    
    // 第二個實體方法
    func doSomething2(a: Int, b: Int) -> Int {
        // 回傳兩個參數的相加值
        return a + b
    }
    
    // 第三個實體方法
    mutating func doSomething3(a: Int) {
        // 修改儲存性屬性 a
        self.a += a
    }
}

var d = StructDemo(a: 11, b: 22)
print(d.doSomething())
d.a = 33
print(d.doSomething())
print(d.doSomething2(a: 55, b: 66))
d.doSomething3(a: 1)
print(d.a)

print()

print("第二個例子")

// 第二個例子
struct StructDemo2 {
    var a = 2
    let b = 5
}

var d2 = StructDemo2()
print(d2.a)
d2.a = 24
print(d2.a)
var d3 = StructDemo2(a: 1)
print(d3.a)
d3.a = 6
print(d3.a)

print()

print("第三個例子")

// 第三個例子
struct StructDemo3 {
    // 型態屬性
    static var count = 0
    
    // 型態方法
    static func doSomething() {
        count += 1
    }
}

print(StructDemo3.count)
StructDemo3.doSomething()
StructDemo3.doSomething()
StructDemo3.doSomething()
print(StructDemo3.count)
