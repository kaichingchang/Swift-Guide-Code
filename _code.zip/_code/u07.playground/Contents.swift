//
//  檔名： u07.playground
//  專案： u07
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
func doSomething1() {
    print("Hi")
}
doSomething1()

print()

print("第二個例子")

// 第二個例子
func doSomething2(a: Int) {
    print(a)
}
doSomething2(a: 22)

print()

print("第三個例子")

// 第三個例子
func doSomething3(_ a: Int) {
    print(a)
}
doSomething3(33)

print()

print("第四個例子")

// 第四個例子
func doSomething4(_ a: Int) -> Int {
    return a
}
doSomething4(40)

print()

print("第五個例子")

// 第五個例子
func doSomething5(a: Int, b: Int) -> Int {
    return a + b
}
doSomething5(a: 23, b: 32)

print()

print("第六個例子")

// 第六個例子
func doSomething6(a: Int, b: Int) -> (Int, Int) {
    return (a + b, a - b)
}
doSomething6(a: 42, b: 21)

print()

print("第七個例子")

// 第七個例子
func join1(str s1: String, mark m: String) -> String {
    return s1 + m
}
join1(str: "Hi", mark: ", ")

print()

print("第八個例子")

// 第八個例子
func join2(s1: String, m: String = "- ") -> String {
    return s1 + m
}
join2(s1: "Hi")

print()

print("第九個例子")

// 第九個例子
func sum(_ numbers: Int...) -> Int {
    var total = 0
    for n in numbers {
        total += n
    }
    
    return total
}
sum(1, 2, 3)
sum(11, 22, 33, 44, 55)

print()

// 第十個例子
print("第十個例子")
func mathFunction(f: (Int, Int) -> Int, a: Int, b: Int) {
    print("結果是 \(f(a, b))")
}
mathFunction(f: doSomething5, a: 45, b: 55)
