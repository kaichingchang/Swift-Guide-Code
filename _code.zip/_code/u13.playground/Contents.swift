//
//  檔名： u13.playground
//  專案： u13
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
class CClass {
    var name: String
    
    init(name: String) {
        self.name = name
        print("\(name)正被初始化。")
    }
    
    deinit {
        print("\(name)正被解初始化。")
    }
}

// 宣告三個 CClass 的選擇型態變數
var demo1: CClass?
var demo2: CClass?
var demo3: CClass?

// 將三個變數都指向同一個 CClass 物件
demo1 = CClass(name: "Tony")
demo2 = demo1
demo3 = demo1

// 將其中兩個變數指向 nil
demo1 = nil
demo2 = nil

// 印出三個變數的 name 屬性
print(demo1?.name ?? "None")
print(demo2?.name ?? "None")
print(demo3?.name ?? "None")

// 將 demo3 指向 nil
demo3 = nil

print()

print("第二個例子")

// 第二個例子
var t1 = ["a":"1", "b":"2"]
print(t1["a"]!)

var t2 = "0"
t2.append(t1["a"]!)
print(t2)

print()
