//
//  檔名： u10.playground
//  專案： u10
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
class ClassDemo {
    var a: Int
    let b: Int
    
    // 建構子
    init() {
        a = 2
        b = 1
    }
    
    // 多載的第一個版本
    func doSomething() -> Int {
        return a + b
    }
    
    // 多載的第二個版本
    func doSomething(a: Int, b: Int) -> Int {
        return a + b
    }
}

var demo1 = ClassDemo()
print(demo1.doSomething())
print(demo1.doSomething(a: 2, b: 3))

print()

print("第二個例子")

// 第二個例子
class ClassDemo2 {
    var t: Double

    // 攝氏溫度的建構子
    init(fromCelsius c: Double) {
        t = c
    }
    // 華氏溫度的建構子
    init(fromFahrenheit f: Double) {
        t = 5 * (f - 32.0) / 9
    }
}

let demo2 = ClassDemo2(fromCelsius: 100.0)
print(demo2.t)
let demo3 = ClassDemo2(fromFahrenheit: 212.0)
print(demo3.t)

print()

print("第三個例子")

// 第三個例子
class ClassDemo3 {
    var a: Int
    
    // 建構子
    init() {
        a = 22
    }
    
    // 解構子
    deinit {
        a = 0
    }
}

var demo4: ClassDemo3? = ClassDemo3()
print(demo4?.a ?? 0)
demo4 = nil
print(demo4?.a ?? 0)

print()

print("第四個例子")

// 第四個例子
// 結構部分
print("結構部分")
struct AStruct {
    var a = 1
    var b = 2
}

var sd1 = AStruct()
print(sd1.a)
var sd2 = sd1
print(sd2.a)
sd1.a = 33
print(sd1.a)
print(sd2.a)

// 類別部分
print("類別部分")
class BClass {
    var a = 1
    var b = 2
}

var cd1 = BClass()
print(cd1.a)
var cd2 = cd1
print(cd2.a)
cd1.a = 33
print(cd1.a)
print(cd2.a)

print()
