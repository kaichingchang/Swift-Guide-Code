//
//  檔名： u08.playground
//  專案： u08
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
enum Numbers {
    case One
    case Two
    case Three
    case Four
}

let choice = Numbers.Three
switch choice {
case .One:
    print("1")
case .Two:
    print("2")
case .Three:
    print("3")
case .Four:
    print("4")
}

print()

print("第二個例子")

// 第二個例子
enum Numbers2 {
    case Five(Int, Int, Int, Int)
    case Six(String)
}

let choice2 = Numbers2.Five(1, 2, 3, 4)
switch choice2 {
case .Five:
    print("5")
case .Six:
    print("6")
}

print()

print("第三個例子")

// 第三個例子
enum Numbers3: Int {
    case Seven = 1
    case Eight = 2
    case Nine = 3
    case Ten = 4
}

let decision = 2
if let choice3 = Numbers3(rawValue: decision) {
    switch choice3 {
    case .Seven:
        print("7")
    case .Eight:
        print("8")
    case .Nine:
        print("9")
    case .Ten:
        print("10")
    }
}
