//
//  檔名： u14.playground
//  專案： u14
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

class Encrypt {
    //MARK: 屬性

    // 英文小寫字母表
    let alphabet = "abcdefghijklmnopqrstwuvxyz"
    // 密碼表
    var code = Array(arrayLiteral: 26)
    
    //MARK: 建構子

    init() {
        // setCode()
    }
    
    //MARK: 方法

    // 設定密碼表
    // func setCode() {}
    
    // 尋找字元在字母表中的索引值
    // func findAlphabetIndex(chr: Character) > Int {}
    
    // 尋找字元在密碼表中的索引值
    // func findCodeIndex(chr: Character) -> Int {}
    
    // 判斷字元是否是英文小寫字母
    // func isLowercase(chr: Character) -> Bool {}
    
    // 用索引值取得密碼表中的字元
    // func findCode(number: Int) -> Character {}
    
    // 用索引值取得字母表中的字元
    // func findLetter(index: Int) -> Character {}
    
    // 編碼的方法
    // func toEncode(str: String) -> String {}
    
    // 解碼的方法
    // func toDecode(str: String) -> String {}
}
