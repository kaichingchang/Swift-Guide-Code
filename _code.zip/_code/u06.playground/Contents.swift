//
//  檔名： u06.playground
//  專案： u06
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
var i1 = 0 // 設定控制變數
var sum1 = 0
while i1 <= 10 { // 條件
    // 迴圈工作區
    sum1 += i1
    i1 += 1 // 調整控制變數值
}
print(sum1)

print()

print("第二個例子")

// 第二個例子
var i2 = 0
var sum2 = 0
repeat {
    sum2 += i2
    i2 += 1
} while i2 <= 10
print(sum2)

print()

print("第三個例子")

// 第三個例子
var sum3 = 0
for item in 0...10 {
    sum3 += item
}
print(sum3)
