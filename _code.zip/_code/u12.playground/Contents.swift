//
//  檔名： u12.playground
//  專案： u12
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/6/17
//

print("第一個例子")

// 第一個例子
enum Wrong: Error {
    case invaildItem1
    case invaildItem2
    case invaildItem3
}

// 會丟出錯誤的函數
func doWrong() throws {
    throw Wrong.invaildItem2
}

// doWrong()

print()

print("第二個例子")

// 第二個例子
do {
    try doWrong()
    // 如果以上沒有發生錯誤
    print("!!!")
}
catch Wrong.invaildItem1 {
    print("invaildItem1")
}
catch Wrong.invaildItem2 {
    print("invaildItem2")
}
catch Wrong.invaildItem3 {
    print("invaildItem3")
}

print()

print("第三個例子")

// 第三個例子
do {
    try doWrong()
    // 如果以上沒有發生錯誤
    print("!!!")
}
catch Wrong.invaildItem1 {
    print("invaildItem1")
}
catch {
    print("Other error!")
}

print()
