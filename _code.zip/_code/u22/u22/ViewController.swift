//
//  ViewController.swift
//  u22
//
//  Created by 張凱慶 on 26/06/2017.
//  Copyright © 2017 kaiching. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

