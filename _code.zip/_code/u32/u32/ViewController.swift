//
//  檔名： ViewController.swift
//  專案： u32
//
//  《Swift 入門指南》 V3.00 的範例程式
//  購書連結
//         Google Play  : https://play.google.com/store/books/details?id=AO9IBwAAQBAJ
//         iBooks Store : https://itunes.apple.com/us/book/id1079291979
//         Readmoo      : https://readmoo.com/book/210034848000101
//         Pubu         : http://www.pubu.com.tw/ebook/65565?apKey=576b20f092
//
//  作者網站： http://www.kaiching.org
//  電子郵件： kaichingc@gmail.com
//
//  作者： 張凱慶
//  時間： 2017/07/02
//

import UIKit
import GameplayKit

class ViewController: UIViewController {
    //MARK: 屬性
    
    //視窗元件屬性
    @IBOutlet weak var question: UITextField!
    @IBOutlet weak var selections: UITextView!
    @IBOutlet weak var scores: UILabel!
    
    //遊戲資料
    let sentenceData = ["What is real?",
                        "How do you define real?",
                        "You're the one that has to walk through it.",
                        "Don't think you are, know you are.",
                        "I'm going to be honest with you.",
                        "There is no spoon.",
                        "Free your mind.",
                        "Believe the unbelievable.",
                        "Follow the white rabbit.",
                        "I'm just another guy.", ""]
    //原始順序
    let array = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    //題目與隨機排列的選項
    var answer = [Int:[Int]]()
    //題目順序
    var answerOrder = [Int]()
    
    //記錄遊戲次數
    var times = 0
    //記錄玩家按下哪個按鈕
    var useranswer: Int?
    //累計分數
    var score = 0
    
    //編碼屬性
    var e = Encrypt()

    //Core data
    static var count = 0
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var tasks: [Results] = []
    
    //MARK: 方法
    
    //按鈕1
    @IBAction func method1(_ sender: UIButton) {
        useranswer = 0
        next()
    }
    
    //按鈕2
    @IBAction func method2(_ sender: UIButton) {
        useranswer = 1
        next()
    }
    
    //按鈕3
    @IBAction func method3(_ sender: UIButton) {
        useranswer = 2
        next()
    }
    
    //按鈕4
    @IBAction func method4(_ sender: UIButton) {
        useranswer = 3
        next()
    }
    
    //處理按下按鈕後的情況
    func next() {
        //檢查玩家是否有答對做分數加減
        if let userinput = useranswer {
            if answerOrder[times] == answer[answerOrder[times]]![userinput] {
                score += 1
            }
            else {
                score -= 1
            }
            
            scores.text = String(score)
        }
        //遊戲次數遞增
        times += 1
        
        //遊戲結束情況處理
        if times == 10 {
            times = 0
            ViewController.count += 1
            
            //將分數寫入資料表
            let task = Results(context: context)
            task.scores = Int64(score)
            task.times = Int64(ViewController.count)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            //回答完所有題目，切換到成績頁面
            let newScene = UIStoryboard(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "Result") as UIViewController
            let appDelegate = (UIApplication.shared.delegate as! AppDelegate)
            appDelegate.window?.rootViewController = newScene
        }
        
        //依次數顯示下一個題目
        showQuestions()
    }
    
    //顯示問題
    func showQuestions() {
        //取得答案字串
        let answerStr = sentenceData[answerOrder[times]]
        //設定題目
        question.text = e.toEncode(answerStr)
        //取得選項索引值
        let one = answer[answerOrder[times]]![0]
        let two = answer[answerOrder[times]]![1]
        let three = answer[answerOrder[times]]![2]
        let four = answer[answerOrder[times]]![3]
        //設定選項
        selections.text = "1: " + sentenceData[one] + "\n" +
            "2: " + sentenceData[two] + "\n" +
            "3: " + sentenceData[three] + "\n" +
            "4: " + sentenceData[four]
    }
    
    //隨機排列問題、答案的組合
    func setAnswerArray() {
        //設定答案與選項
        for item in array {
            answer[item] = [item]
            var count = 0
            var r = -1
            while true {
                r = Int(arc4random() % 10)
                if answer[item]!.contains(r) {
                    continue
                }
                if count == 3 {
                    break
                }
                answer[item]?.append(r)
                count += 1
            }
        }
        
        //攪亂選項順序
        for (item1, item2) in answer {
            answer[item1] = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: item2) as? [Int]
        }
        
        //攪亂題目順序
        answerOrder = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: array) as! [Int]
    }
    
    //MARK: 預設方法
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //載入後執行
        setAnswerArray()
        showQuestions()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

